﻿namespace VTrivia.Model
{
    public class input
    {
        public int grpId {  get; set; }
    }
}
